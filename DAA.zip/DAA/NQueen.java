import java.util.Scanner;

public class NQueen {

    static int n;
    static int[][] board;

    // Check whether queen can be placed
    static boolean isSafe(int row, int col) {

        // Check column
        for (int i = 0; i < row; i++) {
            if (board[i][col] == 1)
                return false; }

        // Check left diagonal
        for (int i = row - 1, j = col - 1;
             i >= 0 && j >= 0; i--, j--) {
            if (board[i][j] == 1)
                return false; }

        // Check right diagonal
        for (int i = row - 1, j = col + 1;
             i >= 0 && j < n; i--, j++) {
            if (board[i][j] == 1)
                return false ; }

        return true; }

    // Backtracking
    static boolean solve(int row) {
        if (row == n)
            return true;
        for (int col = 0; col < n; col++) {

            if (isSafe(row, col)) {
                board[row][col] = 1;

                if (solve(row + 1))
                    return true;
                // Backtrack
                board[row][col] = 0;  }}
        return false; }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of queens: ");
        n = sc.nextInt();

        if (n < 1) {
            System.out.println("Board size must be positive.");
            return;
        }
        System.out.print("Enter first queen's column in row 1 (1 to " + n + "): ");
        int firstColumn = sc.nextInt();
        if (firstColumn < 1 || firstColumn > n) {
            System.out.println("Column is outside the board.");
            return;
        }

        board = new int[n][n];
        board[0][firstColumn - 1] = 1;
        if (solve(1)) {
            System.out.println("Solution:");

            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    System.out.print(board[i][j] + " ");
                }
                System.out.println();
            }

        } else {
            System.out.println("No solution exists.");
        }
        sc.close();
    }
}
