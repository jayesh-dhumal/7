import java.util.*;
public class HuffmanEncoding {

    static class Node {
        char ch;
        int freq;
        Node left, right;

        Node(char ch, int freq) {
            this.ch = ch;
            this.freq = freq;
        }

        Node(int freq, Node left, Node right) {
            this.freq = freq;
            this.left = left;
            this.right = right;
        }  }

    // Generate Huffman codes
    static void generate(Node root, String code,
                         Map<Character, String> map) {

        if (root == null)
            return;

        if (root.left == null && root.right == null) {
            map.put(root.ch, code.isEmpty() ? "0" : code);
            return; }
        generate(root.left, code + "0", map);
        generate(root.right, code + "1", map);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter string: ");
        String str = sc.nextLine();

        // Find frequency
        Map<Character, Integer> freq = new HashMap<>();

        for (char c : str.toCharArray())
            freq.put(c, freq.getOrDefault(c, 0) + 1);

        // Min Priority Queue
        PriorityQueue<Node> pq =
            new PriorityQueue<>(
                (a, b) -> a.freq - b.freq  );
        // Add characters
        for (char c : freq.keySet())
            pq.add(new Node(c, freq.get(c)));
        // Build Huffman Tree
        while (pq.size() > 1) {

            Node a = pq.poll();
            Node b = pq.poll();
            pq.add(new Node(
                a.freq + b.freq, a, b
            ));  }

        Node root = pq.poll();

        // Generate codes
        Map<Character, String> code = new HashMap<>();
        generate(root, "", code);
        // Display codes
        System.out.println("\nHuffman Codes:");

        for (char c : code.keySet())
            System.out.println(c + " : " + code.get(c));

        // Encode string
        String encoded = "";
        for (char c : str.toCharArray())
            encoded += code.get(c);

        System.out.println("\nOriginal String: " + str);
        System.out.println("Encoded String: " + encoded);

        System.out.println("\nTime Complexity: O(n log n)");
        System.out.println("Space Complexity: O(n)");
        sc.close(); }}
