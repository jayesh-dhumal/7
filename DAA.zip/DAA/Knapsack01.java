 import java.util.Scanner;

public class Knapsack01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of items: ");
        int n = sc.nextInt();

        int[] weight = new int[n];
        int[] value = new int[n];
        System.out.println("Enter weight and value of each item:");

        for (int i = 0; i < n; i++) {
            weight[i] = sc.nextInt();
            value[i] = sc.nextInt();
        }

        System.out.print("Enter knapsack capacity: ");
        int capacity = sc.nextInt();

        // DP table
        int[][] dp = new int[n + 1][capacity + 1];
        // Fill table
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= capacity; j++) {


                if (weight[i - 1] <= j) {

                    dp[i][j] = Math.max(
                        dp[i - 1][j],
                        value[i - 1] + dp[i - 1][j - weight[i - 1]]
                    );

                } else {
                    dp[i][j] = dp[i - 1][j]; } } }


        System.out.println("Maximum value = " + dp[n][capacity]);
        // Find selected items
        int j = capacity;

        System.out.print("Selected items: ");

        for (int i = n; i > 0; i--) {

            if (dp[i][j] != dp[i - 1][j]) {

                System.out.print(i + " ");
                j = j - weight[i - 1]; } }
        sc.close(); } }
