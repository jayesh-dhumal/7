// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract EVoting {
    struct Candidate {
        string name;
        uint256 votes;
    }

    address public immutable owner = msg.sender;
    Candidate[] public candidates;
    mapping(address => bool) public eligible;
    mapping(address => bool) public hasVoted;
    bool public closed;

    constructor(string[] memory names) {
        require(names.length >= 2, "Add at least two candidates");
        for (uint256 i = 0; i < names.length; i++) {
            require(bytes(names[i]).length > 0, "Candidate name required");
            candidates.push(Candidate(names[i], 0));
        }
    }

    function registerVoter(address voter) external {
        require(msg.sender == owner && !closed, "Registration unavailable");
        require(voter != address(0), "Invalid voter");
        eligible[voter] = true;
    }

    function vote(uint256 candidateId) external {
        require(!closed && eligible[msg.sender] && !hasVoted[msg.sender], "Vote unavailable");
        require(candidateId < candidates.length, "Invalid candidate");
        hasVoted[msg.sender] = true;
        candidates[candidateId].votes++;
    }

    function candidateCount() external view returns (uint256) {
        return candidates.length;
    }

    function closeVoting() external {
        require(msg.sender == owner, "Owner only");
        closed = true;
    }
}
