// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract StudentRecords {
    struct Student {
        uint256 id;
        string name;
        bool active;
    }

    address public immutable owner = msg.sender;
    Student[] private students;
    event FallbackCalled(address indexed sender, bytes data);

    modifier onlyOwner() {
        require(msg.sender == owner, "Owner only");
        _;
    }

    function create(string calldata name) external onlyOwner returns (uint256 id) {
        require(bytes(name).length > 0, "Enter a name");
        id = students.length;
        students.push(Student(id, name, true));
    }

    function read(uint256 id) external view returns (Student memory) {
        require(id < students.length && students[id].active, "Student missing");
        return students[id];
    }

    function update(uint256 id, string calldata name) external onlyOwner {
        require(id < students.length && students[id].active, "Student missing");
        require(bytes(name).length > 0, "Enter a name");
        students[id].name = name;
    }

    function remove(uint256 id) external onlyOwner {
        require(id < students.length && students[id].active, "Student missing");
        delete students[id];
    }

    fallback() external {
        emit FallbackCalled(msg.sender, msg.data);
    }
}
