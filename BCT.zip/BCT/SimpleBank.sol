// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract SimpleBank {
    mapping(address => uint256) private balances;

    function deposit() external payable {
        require(msg.value > 0, "Send some test Ether");
        balances[msg.sender] += msg.value;
    }

    function withdraw(uint256 amountWei) external {
        uint256 balance = balances[msg.sender];
        require(amountWei > 0 && amountWei <= balance, "Invalid amount");
        balances[msg.sender] = balance - amountWei;
        (bool sent, ) = payable(msg.sender).call{value: amountWei}("");
        require(sent, "Transfer failed");
    }

    function showBalance() external view returns (uint256) {
        return balances[msg.sender];
    }
}
